import os, json, re, subprocess, textwrap, random, sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
import requests
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).parent
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
UPLOAD = os.getenv("UPLOAD_TO_YOUTUBE", "false").lower() == "true"
PUBLISH_PUBLICLY = os.getenv("PUBLISH_PUBLICLY", "false").lower() == "true"

def load_topic():
    # Deterministic rotation by UTC date: works on stateless GitHub runners.
    cards = json.loads((ROOT / "topics.json").read_text(encoding="utf-8"))
    if not cards:
        raise RuntimeError("topics.json is empty.")
    day_number = (datetime.now(timezone.utc).date() - datetime(2026, 1, 1, tzinfo=timezone.utc).date()).days
    return cards[day_number % len(cards)]

def ask_gemini(card):
    if not API_KEY:
        raise RuntimeError("Missing GEMINI_API_KEY. Add it as a GitHub Actions secret.")
    prompt = f"""
Create an original FACTVERSE Hinglish YouTube Short, 40-50 seconds, from ONLY this approved fact card.
Do not add facts not supported by the card. Do not invent statistics, quotes, dates or sources.
If a claim is outside the card, omit it. Use natural spoken Hinglish, easy for Indian viewers.
Include a 2-second hook, 5-6 short scenes, a clear explanation, a nuance/caveat, and a short CTA.
Return JSON only with keys: title, description, script, scenes (array of {{"visual":"...","onscreen_text":"..."}}), tags.
Topic: {card['topic']}
Approved facts: {json.dumps(card['approved_fact_card'], ensure_ascii=False)}
Reference names: {json.dumps(card['reference_names'])}
Reference URLs: {json.dumps(card['reference_urls'])}
"""
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={API_KEY}"
    r = requests.post(url, json={
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.45, "responseMimeType": "application/json"}
    }, timeout=90)
    if r.status_code == 429:
        raise RuntimeError("Gemini free-tier quota/rate limit reached. Wait for quota reset; no paid fallback is configured.")
    r.raise_for_status()
    data = r.json()
    raw = data["candidates"][0]["content"]["parts"][0]["text"]
    return json.loads(raw)

def clean_text(s):
    return re.sub(r"\s+", " ", str(s)).strip()

def get_font(size, bold=False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"
    ]
    for p in candidates:
        if Path(p).exists():
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()

def make_scene(text, idx, total, path):
    w, h = 1080, 1920
    img = Image.new("RGB", (w, h), (8, 14, 35))
    px = img.load()
    # Original abstract radial-style gradient background.
    for y in range(h):
        for x in range(w):
            glow = max(0, 1 - (((x-w*0.5)**2 + (y-h*0.35)**2)**0.5)/(w*0.9))
            px[x,y] = (int(7+glow*15), int(12+glow*25), int(32+glow*65))
    d = ImageDraw.Draw(img)
    d.ellipse((90, 300, 990, 1200), outline=(54, 107, 190), width=5)
    d.ellipse((210, 420, 870, 1080), outline=(35, 67, 125), width=4)
    d.text((70, 100), "FACTVERSE", font=get_font(54, True), fill=(120, 190, 255))
    d.text((70, 175), "KNOW MORE. WONDER MORE.", font=get_font(27), fill=(185, 202, 228))
    # Wrap text to fit width.
    words = clean_text(text).split()
    lines, line = [], ""
    font = get_font(68, True)
    for word in words:
        trial = (line + " " + word).strip()
        if d.textbbox((0,0), trial, font=font)[2] > 900 and line:
            lines.append(line); line = word
        else:
            line = trial
    if line: lines.append(line)
    y = 760 - (len(lines)*90)//2
    for ln in lines:
        box = d.textbbox((0,0), ln, font=font)
        d.text(((w-(box[2]-box[0]))//2, y), ln, font=font, fill=(255,255,255), stroke_width=2, stroke_fill=(10,20,45))
        y += 95
    d.text((70, 1770), f"{idx:02d} / {total:02d}", font=get_font(32), fill=(150,180,220))
    img.save(path, quality=92)

def render_video(content):
    script = clean_text(content["script"])
    (OUT / "script.txt").write_text(script, encoding="utf-8")
    (OUT / "content.json").write_text(json.dumps(content, ensure_ascii=False, indent=2), encoding="utf-8")
    scenes = content.get("scenes") or [{"visual":"Abstract science visual","onscreen_text":s} for s in [script[i:i+55] for i in range(0,len(script),55)]]
    scenes = scenes[:7]
    # Build one narration WAV using espeak-ng.
    wav = OUT / "voice.wav"
    subprocess.run(["espeak-ng", "-v", "en-in", "-s", "145", "-w", str(wav), script], check=True)
    duration = float(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(wav)
    ]).decode().strip())
    per = max(3.0, duration / max(1, len(scenes)))
    concat = OUT / "scenes.txt"
    lines = []
    for i, scene in enumerate(scenes, 1):
        p = OUT / f"scene_{i:02d}.jpg"
        make_scene(scene.get("onscreen_text") or scene.get("visual") or "Amazing facts", i, len(scenes), p)
        lines.append(f"file '{p.as_posix()}'\nduration {per:.3f}")
    lines.append(f"file '{(OUT / f'scene_{len(scenes):02d}.jpg').as_posix()}'")
    concat.write_text("\n".join(lines), encoding="utf-8")
    silent = OUT / "silent.mp4"
    subprocess.run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat),
        "-vf", "fps=30,format=yuv420p", "-t", str(duration),
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "25", str(silent)
    ], check=True)
    final = OUT / "factverse.mp4"
    subprocess.run([
        "ffmpeg", "-y", "-i", str(silent), "-i", str(wav),
        "-c:v", "copy", "-c:a", "aac", "-b:a", "128k",
        "-shortest", "-movflags", "+faststart", str(final)
    ], check=True)
    return final

def upload_youtube(video_path, content):
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload
    cid = os.getenv("YOUTUBE_CLIENT_ID", "")
    csecret = os.getenv("YOUTUBE_CLIENT_SECRET", "")
    refresh = os.getenv("YOUTUBE_REFRESH_TOKEN", "")
    if not all([cid, csecret, refresh]):
        raise RuntimeError("YouTube upload requested but OAuth secrets are missing.")
    creds = Credentials(
        None, refresh_token=refresh,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=cid, client_secret=csecret,
        scopes=["https://www.googleapis.com/auth/youtube.upload"]
    )
    yt = build("youtube", "v3", credentials=creds)
    title = clean_text(content.get("title", "FACTVERSE Amazing Fact"))[:95]
    description = clean_text(content.get("description", "")) + "\n\n" + " ".join(content.get("tags", []))
    status = {"privacyStatus": "private", "selfDeclaredMadeForKids": False}
    # Public scheduling is deliberately opt-in and only attempted after project approval.
    if PUBLISH_PUBLICLY:
        publish_at = (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat(timespec="seconds").replace("+00:00", "Z")
        status["publishAt"] = publish_at
    body = {
        "snippet": {
            "title": title,
            "description": description[:4900],
            "tags": [clean_text(t)[:30] for t in content.get("tags", [])[:15]],
            "categoryId": "28"
        },
        "status": status
    }
    request = yt.videos().insert(
        part="snippet,status",
        body=body,
        media_body=MediaFileUpload(str(video_path), mimetype="video/mp4", resumable=True)
    )
    response = request.execute()
    (OUT / "youtube_upload.json").write_text(json.dumps(response, indent=2), encoding="utf-8")

def main():
    card = load_topic()
    content = ask_gemini(card)
    content["reference_sources_for_manual_check"] = card["reference_urls"]
    content["topic_card_id"] = card["id"]
    video = render_video(content)
    if UPLOAD:
        upload_youtube(video, content)
    print(f"Generated: {video}")
    print(f"Upload enabled: {UPLOAD}; public scheduling: {PUBLISH_PUBLICLY}")

if __name__ == "__main__":
    main()
