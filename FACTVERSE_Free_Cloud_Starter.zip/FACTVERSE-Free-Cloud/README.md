# FACTVERSE — Free Cloud Automation Starter

Android-controlled, GitHub Actions based starter for a no-paid-subscription YouTube Shorts pipeline.

## What this starter does
1. Runs on a GitHub Actions schedule (or manually).
2. Reads one pre-approved topic card from `topics.json`.
3. Uses the Gemini Developer API free tier to draft a Hinglish script and metadata.
4. Generates narration with open-source `espeak-ng` (no paid TTS API).
5. Creates a simple original 9:16 motion-style video using Pillow + FFmpeg.
6. Optionally uploads to YouTube using OAuth credentials stored as GitHub Secrets.

**Important:** This is a starter implementation, not a guarantee of unlimited or unattended publishing. Free API quotas can change or run out. A fact card is a research starting point, not proof; verify factual claims before enabling public scheduling. YouTube API projects that have not passed the required audit may be restricted to private uploads.

## Android-only setup
You can create the repository and add secrets using Chrome on Android. The actual video render runs on GitHub's hosted runner, not on your phone.

### 1) Create a private GitHub repository
- Open https://github.com/new
- Name: `factverse-free-cloud`
- Choose **Private**.
- Create repository.
- Upload all files from this ZIP using **Add file → Upload files**. Keep folder paths intact. (Alternatively use GitHub's web editor to create each file.)

GitHub Free currently includes a monthly Actions allowance for private repositories; public-repository standard runner usage is free, but a public repo exposes your source code. Check current plan limits before relying on a schedule.

### 2) Get a Gemini API key (free tier)
- Open https://aistudio.google.com/app/apikey
- Create an API key.
- Check current free-tier model availability and rate limits at https://ai.google.dev/gemini-api/docs/pricing
- In GitHub repo: Settings → Secrets and variables → Actions → New repository secret
- Name: `GEMINI_API_KEY`
- Value: your key.

Do not paste the key into code or commit it.

### 3) Optional YouTube upload credentials
Create a Google Cloud project, enable **YouTube Data API v3**, configure OAuth consent, and create OAuth credentials. A browser-based route for obtaining a refresh token is Google's OAuth 2.0 Playground:
- In Google Cloud, create an OAuth **Web application** client and add `https://developers.google.com/oauthplayground` as an authorized redirect URI.
- Open https://developers.google.com/oauthplayground
- Open the settings gear and select **Use your own OAuth credentials**; enter that client ID and secret.
- In Step 1, enter/select `https://www.googleapis.com/auth/youtube.upload`, authorize with the Google account that owns the channel, and grant consent.
- In Step 2, exchange the authorization code. Copy the refresh token from the response.
- Store the following as GitHub Actions secrets:
- `YOUTUBE_CLIENT_ID`
- `YOUTUBE_CLIENT_SECRET`
- `YOUTUBE_REFRESH_TOKEN`

Never share these values in chat or commit them. OAuth setup is sensitive; if you cannot securely obtain a refresh token, leave these secrets unset. The workflow will only build the video and save it as an artifact.

Official docs:
- https://developers.google.com/youtube/v3/getting-started
- https://developers.google.com/youtube/v3/guides/authentication
- https://developers.google.com/youtube/v3/docs/videos/insert

### 4) Configure the workflow
- Open `.github/workflows/factverse.yml`
- Change `UPLOAD_TO_YOUTUBE: "false"` to `"true"` only after testing.
- Keep `PUBLISH_PUBLICLY: "false"` until the YouTube API project is approved and the channel's first uploads have been checked.
- The default schedule is 09:00 UTC (14:30 IST) every day. GitHub scheduled workflows can be delayed; they are not exact-time guarantees.
- You can run it manually from the Actions tab → FACTVERSE Daily Pipeline → Run workflow.

### 5) First test
Run manually with upload disabled. Check the generated `factverse.mp4`, `content.json`, and `script.txt` in the workflow artifact. Listen to the audio and verify every claim. Do not publish a fact you have not checked.

## Automation limits and safety
- Gemini free tier has model-specific RPM/TPM/RPD limits and can change. A quota error stops the run; it does not trigger paid billing automatically unless you separately enable billing.
- YouTube Data API requires OAuth consent. The `videos.insert` endpoint has quota limits. Unverified API projects may have upload restrictions.
- YouTube scheduling requires a private upload with a future `publishAt` timestamp. This project defaults to private uploads.
- This pipeline does not scrape or reuse other creators' videos. Visuals are generated locally from original templates.
- `espeak-ng` is robotic. Replace only with a TTS provider whose free licence/limits you have checked, or record your own voice.
- YouTube monetization is not guaranteed. Repetitive or mass-produced low-value content may not qualify.

## Project files
- `topics.json`: fact cards to use as controlled source material.
- `pipeline.py`: content generation, narration, rendering and optional upload.
- `.github/workflows/factverse.yml`: daily schedule and manual run.
- `requirements.txt`: Python dependencies.

## Cost
This repository is designed to avoid paid subscriptions and paid APIs. It uses free tiers and open-source software. A free tier is not an unlimited service; availability and terms may change.
